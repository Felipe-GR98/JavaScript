


  // 1- Tag h2 verde
  

  //2- pai da classe button vermelho
 

  // 3- filhos da classe module azul
  

  // 4- item da lista de índice 2 da classe module utilizando a função eq() verde
  
  
  //5- 1° da lista myList amarelo
  

  // 6- ultimo da lista slideshow preto
 
  
  // 7- se 1° filho de Search é um form, alert correto: não
  
  
  // 8- todas ul, exceto id slideshow, azul
  
  
  // 9- li com p rosa
 
  
  // 10- alterar conteudo classe myListItem para “Este é um novo item de lista”

  
  // 11- próximo elemento após o elemento de classe selected cinza
  

  // 12- elemento anterior ao elemento de classe input_text cinza
  
  
  // 13- irmãos id listItem_2 verde
  
  
  // 14- Todos src amarelo
  
  
  // 15- id header e  id nav =>  classe selected (Utilizando um seletor que contenha esse caminho)
  

  // 16- select  atributo type=”text”
 

  // 17- selecionar todos value
  
  // 18- type diferente de submit vermelho
   

  // 19- href que inicia com blog  verde
  

  // 20- value que termina com a vermelho
 
  
  // 21- href HTML cinza
  